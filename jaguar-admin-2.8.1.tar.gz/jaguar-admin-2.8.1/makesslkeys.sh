#!/bin/bash

type openssl >/dev/null 2>&1
if (($?==0)); then
	echo "openssl is found, proceed ..."
else
	echo "openssl is NOT found, use default keys files"
fi

export LD_LIBRARY_PATH=/usr/local/lib64
openssl req -x509 -newkey rsa:4096 -keyout privatekey.pem -out publiccert.pem -days 36500 -nodes \
  -subj '/O=datajaguar/OU=dept/CN=www.datajaguar.com'
