#!/bin/bash

###################################################################################
## Retrieve backup data from remote backup hosts
## Make sure user's password is same on the remote backup hosts and jaguar hosts.
##
##  ./restorefromremote.sh  <RemoteHostIP> 
##  ./restorefromremote.sh  
##
##  If RemoteHostIP is not given, user will be asked to provide one
##  If CurrentUserPasswordOnRemoteHost is not given, public key is tried.
##
###################################################################################

sleep 3
. `dirname $0`/jaguarenv

export PATH=/usr/sbin:$PATH
hn=`hostname`



remip=$1

if [[ "x$remip" = "x" ]]; then
    ### get remote backup server
    ### REMOTE_BACKUP_SERVER=ip1|ip2

    remh=`grep REMOTE_BACKUP_SERVER $JAGUAR_HOME/jaguar/conf/server.conf|grep -v '#'|awk -F'=' '{print $2}'`
    if [[ "x$remh" = "x" ]]; then
       	echo "REMOTE_BACKUP_SERVER is not setup in $JAGUAR_HOME/jaguar/conf/server.conf on $hn"
       	echo "Data cannot be restored, quit"
       	exit 1
    fi

   	echo "Your remote backup servers: $remh"
   	echo -n "Please choose a remote server by its IP adddress: "
   	read remip
   	if [[ "x$remip" = "x" ]]; then
   		echo "No IP address is entered, please try again"
   		exit 2
   	fi
fi

echo "OK, we will restore data from $remip ..."

ips=`hostname -I`
hostips=`cat $JAGUAR_HOME/jaguar/conf/host.conf`

echo "Detected Jaguar server hosts: [$hostips]"

((found=0))
myip=""
for ip in $ips
do
	for hostip in $hostips
	do
		if [[ "x$ip" = "x$hostip" ]]; then
			myip=$ip
			((found=1))
			break
		fi
	done

	if (( found == 1 )); then
		break
	fi

done

echo "My host: [$myip]"
if [[ "x$myip" = "x" ]]; then
	echo "Cannot get self IP address, exit"
	exit 1
fi


arrhostips=(`cat $JAGUAR_HOME/jaguar/conf/host.conf`)
htot=${#arrhostips[@]}
if ((htot==0)); then
	echo "No Jaguar in conf/host.conf quit"
	exit 1
fi

previp=""
nextip=""
((mynum=0))
for ip in $hostips
do
	if [[ "x$ip" = "x$myip" ]]; then
		break
	fi
	((mynum=num+1))
done

((prevnum=mynum-1))
if (( prevnum< 0 )); then
	((prevnum = prevnum + htot ))
fi

((nextnum=mynum+1))
if (( nextnum >= htot)); then
	(( nextnum = nextnum - htot ))
fi

previp=${arrhostips[prevnum]}
nextip=${arrhostips[nextnum]}

#1. scp remoteBackupIP:/home/jaguar/jaguarback/$myip/ to $JAGUAR_HOME/jaguar/data/
#2. scp remoteBackupIP:/home/jaguar/jaguarback/$nextHostOfCurrentJaguar/ to $JAGUAR_HOME/jaguar/ndata/
#3. scp remoteBackupIP:/home/jaguar/jaguarback/$previousHostOfCurrentJaguar/ to $JAGUAR_HOME/jaguar/pdata/
JAGD=$JAGUAR_HOME/jaguar
JAGB=$JAGUAR_HOME/jaguarbackup

echo "Stop Jaguar Server ..."
$JAGD/bin/jaguarstop -f

### If one server only
if ((htot==1)); then
	echo "Sync data from $remip/$myip/ to $JAGD/data/ ..."
	rsync -q --contimeout=10 --password-file=$JAGD/conf/tmpsyncpass.txt -az $remip::jaguardata/$myip/ $JAGD/data/
else 
	### get pdata
	echo "Sync data from $remip/$previp/ to $JAGD/pdata/ ..."
	rsync -q --contimeout=10 --password-file=$JAGD/conf/tmpsyncpass.txt -az $remip::jaguardata/$previp/ $JAGD/pdata/
	if (( htot > 2 )); then
		### get ndata
		echo "Sync data from $remip/$nextip/ to $JAGD/ndata/ ..."
		rsync -q --contimeout=10 --password-file=$JAGD/conf/tmpsyncpass.txt -az $remip::jaguardata/$nextip/ $JAGD/ndata/
	fi
fi

echo "Please start jaguar server on all hosts in the cluster"

