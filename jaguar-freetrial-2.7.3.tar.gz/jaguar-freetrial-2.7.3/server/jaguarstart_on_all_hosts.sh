#!/bin/bash

##############################################################################################################
##
##  Start Jaguar Server On All Hosts
##
##  ./jaguarstart_on_all_hosts.sh
##
##############################################################################################################

if [[ ! -f "$HOME/.jaguarhome" ]]; then
	echo "Jaguar has not been installed, quit"
	exit 1
fi

JAGUAR_HOME=`cat $HOME/.jaguarhome`
hostfile="$JAGUAR_HOME/jaguar/conf/cluster.conf"
allhosts=`cat $hostfile`

if [[ -f "$hostfile" ]]; then
    ## echo "OK, $hostfile is found"
	/bin/true
else
    echo "$hostfile is not found, exit"
    exit 1
fi

for h in $allhosts
do
    echo "ssh $h $JAGUAR_HOME/jaguar/bin/jaguarstart"
    ssh $h "$JAGUAR_HOME/jaguar/bin/jaguarstart"
done

echo "Jaguar database has been started on all hosts"

