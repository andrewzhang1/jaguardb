#!/bin/bash

##############################################################################################################
##
##  Start Jaguar Server On All Hosts
##
##  ./jaguarstatus_on_all_hosts.sh
##
##  exit code 0: true if all servers running
##       code = N:  N servers not running
##
##############################################################################################################

if [[ ! -f "$HOME/.jaguarhome" ]]; then
	echo "Jaguar has not been installed, quit"
	exit 1
fi

JAGUAR_HOME=`cat $HOME/.jaguarhome`
hostfile="$JAGUAR_HOME/jaguar/conf/cluster.conf"
allhosts=`cat $hostfile`

if [[ -f "$hostfile" ]]; then
    ## echo "OK, $hostfile is found"
	/bin/true
else
    echo "$hostfile is not found, exit"
    exit 1
fi

((rc=0))
for h in $allhosts
do
    echo "ssh $h $JAGUAR_HOME/jaguar/bin/jaguarstatus"
    ssh $h "$JAGUAR_HOME/jaguar/bin/jaguarstatus" 
	### exit code 0 fo true, meaning running.  1 as false for not running
	ecode=$?
	((rc=rc+ecode))
done

#echo "jaguarstatus_on_all_hosts.sh exit=$rc"
exit $rc

