#!/bin/bash


if [[ ! -f "$HOME/.jaguarhome" ]]; then
    echo "Jaguar has not been installed, quit"
    exit 1
fi

JAGUAR_HOME=`cat $HOME/.jaguarhome`
JAD_HOME=$JAGUAR_HOME/../jagadmin

dname=`dirname $0`
if [[ "x$dname" = "x." ]] ; then
    dname=`pwd -P`
fi

ver=`basename $dname`
#tarfile="${ver}.tar.gz"
#tarpathfile="${dname}.tar.gz"

###
cd $dname


/bin/mkdir -p $JAD_HOME/log
/bin/mkdir -p $JAD_HOME/bin
/bin/mkdir -p $JAD_HOME/data
/bin/mkdir -p $JAD_HOME/conf

if [[ -f "makesslkeys.sh" ]]; then
	echo "Generate key files for SSL connection of httpd ..."
	./makesslkeys.sh
else
	echo "Direcgory $dname has no makesslkeys.sh script, quit"
	exit 1
fi

if [[ -f "$JAD_HOME/bin/jagadminstop" ]]; then
	echo "Stopping jagadmin server ..."
	/bin/cp -f jagadminstop $JAD_HOME/bin/
    $JAD_HOME/bin/jagadminstop
	echo "Stopped jagadmin server "
fi

if [[ -f index.cgi ]]; then
	echo "Copy index.cgi jagadmin programs to  $JAD_HOME/bin ..."
else
	echo "index.cgi program not found in $dname, quit"
	exit 1
fi


/bin/cp -f jagadmin* index.cgi makesslkeys.sh jaguarall* jaguarop $JAD_HOME/bin
if [[ -f "$JAD_HOME/bin/jagadminstart" ]]; then
	echo "Starting jagadmin server ..."
    $JAD_HOME/bin/jagadminstart
	echo "Started jagadmin server"
fi

if type httpd >/dev/null 2>&1
then
    echo "Your httpd server exists already"
    echo
    echo -n "httpd server root directory: "
    rootdir=`httpd -V |grep HTTPD_ROOT| awk '{print $2}'|awk -F'=' '{gsub(/"/, "", $2);print $2}'`
    echo "$rootdir"
    echo
    echo -n "httpd server config file: "
    cfgfile=`httpd -V |grep SERVER_CONFIG_FILE| awk '{print $2}'|awk -F'=' '{gsub(/"/, "", $2);print $2}'`
    echo "$rootdir/$cfgfile"
    echo
    echo "Files in $rootdir/conf.d directory:"
    /bin/ls -lrt $rootdir/conf.d/
    echo
	echo "Installed jagdmin successfully in $DIR/bin"
	echo "Please read the readme file for further instructions"
    echo
else
    echo "Apache httpd server does not exist on the host."
    echo "You need to install it following the instructions in the readme file."
    echo
fi

echo "Please copy the index.cgi file to your httpd /cgi-bin/ directory"
echo

