#!/bin/bash

##############################################################################################################
##
##  Stop Jaguar Server On All Hosts
##
##  ./jaguarstop_on_all_hosts.sh
##
##############################################################################################################

if [[ ! -f "$HOME/.jaguarhome" ]]; then
	echo "Jaguar has not been installed, quit"
	exit 1
fi

JAGUAR_HOME=`cat $HOME/.jaguarhome`
hostfile="$JAGUAR_HOME/jaguar/conf/cluster.conf"
allhosts=`cat $hostfile`

if [[ -f "$hostfile" ]]; then
    ## echo "OK, $hostfile is found"
	/bin/true
else
    echo "$hostfile is not found, exit"
    exit 1
fi

arr=($allhosts)
numhosts=${#arr[@]}
#echo "there are $numhosts hosts hosts=[$allhosts]"
for h in $allhosts
do
    echo "ssh $h $JAGUAR_HOME/jaguar/bin/jaguarstop $@"
    ssh $h "$JAGUAR_HOME/jaguar/bin/jaguarstop $@" &
done


### wait until all jaguars have been stopped
while true
do
	$JAGUAR_HOME/jaguar/bin/jaguarstatus_on_all_hosts.sh
	notrunning=$?
	((running=numhosts-notrunning))
	if (( running > 0 ))
	then
		date
	    echo "There are still $running jaguar servers running, wait ..."
	    sleep 5
	else
		break
	fi
	
done

echo "Jaguar database has been stopped on all $numhosts hosts"

