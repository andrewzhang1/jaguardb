#!/bin/bash

##############################################################################################################
##
##  Server Uninstallation Script
##
##  ./uninstall_jaguar_database_on_all_hosts.sh
##
##############################################################################################################

if [[ ! -f "$HOME/.jaguarhome" ]]; then
	echo "Jaguar has not been installed, quit"
	exit 1
fi
jaguarhome=`cat $HOME/.jaguarhome`

hostfile="$HOME/.jaghostfile"
if [[ ! -f "$hostfile" ]]; then
	echo "Jaguar has not been installed, quit"
	exit 1
fi
allhosts=`cat $hostfile`

JAGUAR_HOME=$jaguarhome
if [[ -e "$JAGUAR_HOME" ]]; then
    echo "OK, uninstall jaguar files from $JAGUAR_HOME ..."
else
    echo "JAGUAR_HOME $JAGUAR_HOME does not exist, exit"
    exit 1
fi

if [[ "x$JAGUAR_HOME" = "x$HOME" ]]; then
	echo "Wrong $JAGUAR_HOME exit"
	exit 1
fi


if [[ -f "$hostfile" ]]; then
    ## echo "OK, $hostfile is found"
	/bin/true
else
    echo "$hostfile is not found, exit"
    exit 1
fi

if [[ -f "$JAGUAR_HOME/bin/jaguarstop_on_all_hosts.sh" ]]; then
    echo "Stop Jaguar on all hosts ..."
    echo "$JAGUAR_HOME/bin/jaguarstop_on_all_hosts.sh"
    $JAGUAR_HOME/bin/jaguarstop_on_all_hosts.sh
fi


for h in $allhosts
do
    echo ssh $h /bin/rm -rf $JAGUAR_HOME
    ssh $h "/bin/rm -rf $JAGUAR_HOME"
done

echo "Jaguar database has been uninstalled on all hosts"

