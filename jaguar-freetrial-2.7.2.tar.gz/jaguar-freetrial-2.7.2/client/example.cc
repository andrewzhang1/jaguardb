#include  <stdio.h>
#include  <stdlib.h>
#include  <unistd.h>
#include  <string.h>
#include  <JaguarAPI.h>


int main( int argc, char *argv[] )
{
    const char username[]="test";
    const char passwd[]="test";
    const char dbname[]="test";
	const char  *unixSocket = NULL;
    short port = 8888;
	int rc;
    
	JaguarAPI jag;
    
    if ( ! jag.connect(  "127.0.0.1", port, username, passwd, dbname, unixSocket, 0 ) ) {
        printf( "Error connect\n");
        jag.close( );
        exit(1);
    }
    
	char  query[1024];
	memset( query, 0, 1024 );
	sprintf( query, "insert into user values ( 'larryz', '99842', 'danville', 'larryzx' )" );
    rc = jag.query( query ); 
	if ( ! rc ) {
        printf( "Error jagQuery insert\n");
        jag.close( );
        exit(1);
	}

	sprintf( query, "select * from user");
	rc = jag.query( query );
	if ( ! rc ) {
        printf( "Error jagQuery select [%s]\n", jag.error() );
        jag.close( );
        exit(1);
	}

    while ( jag.reply( ) ) {
		char *value = jag.getValue( "uid");
		printf("uid='%s' ", value );
		free( value );

		value = jag.getValue( "test.user.zip");
		printf("zip='%s' ", value );
		free( value );

		printf("\n"); 
    }

	if ( jag.hasError( ) ) {
		printf("Error: %s\n", jag.error( ) );
	}

    jag.close( );
}

