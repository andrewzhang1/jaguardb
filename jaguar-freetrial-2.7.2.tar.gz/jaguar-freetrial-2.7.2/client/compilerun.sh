
JAGUAR_HOME=$HOME
LIBPATH=$JAGUAR_HOME/jaguar/lib
export LD_LIBRARY_PATH=$LIBPATH

javac -cp $LIBPATH/jaguar-jdbc-2.0.jar:.  example.java
java -Djava.library.path=$LIBPATH -cp $LIBPATH/jaguar-jdbc-2.0.jar:. example

javac -cp $LIBPATH/jaguar-jdbc-2.0.jar:.  JaguarJDBCTest.java
java -Djava.library.path=$LIBPATH -cp $LIBPATH/jaguar-jdbc-2.0.jar:. JaguarJDBCTest

g++ -I$JAGUAR_HOME/jaguar/include -o example example.cc $JAGUAR_HOME/jaguar/lib/libjaguar.a 
