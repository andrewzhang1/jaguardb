#!/bin/bash

###################################################################################
## Retrieve backup data from remote backup hosts
## Make sure user's password is same on the remote backup hosts and jaguar hosts.
##
##  ./restorefromremote.sh  <RemoteHostIP> 
##  ./restorefromremote.sh  
##
##  If RemoteHostIP is not given, user will be asked to provide one
##
###################################################################################

sleep 1
. `dirname $0`/jaguarenv

export PATH=/usr/sbin:$PATH
g_hn=`hostname`

g_clusterIPs=""


g_ips=""
function getLocalIPs()
{
    ipv4="[[:digit:]]{1,3}\.[[:digit:]]{1,3}\.[[:digit:]]{1,3}\.[[:digit:]]{1,3}"
    loop="127.0.0.1"
	un=`uname -o`
    if [[ "x$un" = "xMsys" ]]; then
        g_ips=`ipconfig|grep -i addr|egrep "$ipv4"|grep -v "$loop"|awk -F: '{print $2}'`
    elif [[ "x$un" = "xGNU/Linux" ]]; then
        g_ips=`/sbin/ifconfig|grep -i addr|egrep "$ipv4"|grep -v "$loop"|awk '{print $2}'|cut -d: -f2`
    else
        g_ips=`/sbin/ifconfig|grep -i addr|egrep "$ipv4"|grep -v "$loop"|awk '{print $2}'|cut -d: -f2`
    fi
}

function findClusterHosts
{
	myip=$1
	conffile="$JAGUAR_HOME/conf/cluster.conf"
	echo "Conf file is $conffile"
	tmpfile="/tmp/nxjrpSjZUjsK"
	tmpfile2="/tmp/nxjrpKsjdBwx2"
	sed -e '/^\s*$/d' $conffile > $tmpfile
	line1=`head -1 $tmpfile`
	nline=`wc -l $tmpfile|cut -d' ' -f1`
	((lessone=0))
	((lessone=nline-1))
	if echo $line1|grep -q '#'
	then
		tail -$lessone $tmpfile > $tmpfile2
	else
		cat $tmpfile > $tmpfile2
	fi

	### cluster number $myip is in
	((mycluster=0))
	while read line
	do
		if [[ "x$myip" = "x$line" ]]
		then
			break
		else
		    if echo $line|grep -q '#'
			then
				((mycluster=mycluster+1))
			fi
		fi
	done < "$tmpfile2"

	((cluster=0))
	g_clusterIPs=""
	while read line
	do
	    if echo $line|grep -q '#'
		then
			((cluster=cluster+1))
		else
			if ((cluster==mycluster)); then
				g_clusterIPs="$g_clusterIPs $line"
			fi
		fi

	done < "$tmpfile2"

	/bin/rm -f $tmpfile $tmpfile2
}

remip=$1

if [[ "x$remip" = "x" ]]; then
    ### get remote backup server
    ### REMOTE_BACKUP_SERVER=ip1|ip2

    remh=`grep REMOTE_BACKUP_SERVER $JAGUAR_HOME/conf/server.conf|grep -v '#'|awk -F'=' '{print $2}'`
    if [[ "x$remh" = "x" ]]; then
       	echo "REMOTE_BACKUP_SERVER is not setup in $JAGUAR_HOME/conf/server.conf on $g_hn"
       	echo "Data cannot be restored, quit"
       	exit 1
    fi

   	echo "Your remote backup servers: $remh"
   	echo -n "Please choose a remote server by its IP adddress: "
   	read remip
   	if [[ "x$remip" = "x" ]]; then
   		echo "No IP address is entered, please try again"
   		exit 2
   	fi
fi

echo "OK, we will restore data from $remip ..."

hostips=`cat $JAGUAR_HOME/conf/cluster.conf|grep -v '#'`
getLocalIPs

#echo "Detected Jaguar server hosts: [$hostips]"

((found=0))
myip=""
for ip in $g_ips
do
	for hostip in $hostips
	do
		if [[ "x$ip" = "x$hostip" ]]; then
			myip=$ip
			((found=1))
			break
		fi
	done

	if (( found == 1 )); then
		break
	fi

done

echo "My host: [$myip]"
if [[ "x$myip" = "x" ]]; then
	echo "Cannot get self IP address, exit"
	exit 1
fi


### within mycluster
findClusterHosts $myip
#arrhostips=(`cat $JAGUAR_HOME/conf/cluster.conf`)
arrhostips=($g_clusterIPs)
htot=${#arrhostips[@]}
if ((htot==0)); then
	echo "No Jaguar hosts in conf/cluster.conf quit"
	exit 1
fi

echo "There are $htot hosts in current cluster"

previp=""
nextip=""
((mynum=0))
for ip in $g_clusterIPs
do
	if [[ "x$ip" = "x$myip" ]]; then
		break
	fi
	((mynum=num+1))
done

((prevnum=mynum-1))
if (( prevnum< 0 )); then
	((prevnum = prevnum + htot ))
fi

((nextnum=mynum+1))
if (( nextnum >= htot)); then
	(( nextnum = nextnum - htot ))
fi

previp=${arrhostips[prevnum]}
nextip=${arrhostips[nextnum]}

echo "previp=$previp myip=$myip nextip=$nextip"


#1. scp remoteBackupIP:/home/jaguar/jaguarback/$myip/ to $JAGUAR_HOME/data/
#2. scp remoteBackupIP:/home/jaguar/jaguarback/$nextHostOfCurrentJaguar/ to $JAGUAR_HOME/ndata/
#3. scp remoteBackupIP:/home/jaguar/jaguarback/$previousHostOfCurrentJaguar/ to $JAGUAR_HOME/pdata/
JAGD=$JAGUAR_HOME

echo "Stop Jaguar Server ..."
$JAGD/bin/jaguarstop -f

### If one server only
if ((htot==1)); then
	echo "Sync data from $remip/$myip/ to $JAGD/data/ ..."
	rsync -q --contimeout=10 --password-file=$JAGD/conf/tmpsyncpass.txt -az $remip::jaguardata/$myip/ $JAGD/data/
else 
	### get pdata
	echo "Sync data from $remip/$previp/ to $JAGD/pdata/ ..."
	rsync -q --contimeout=10 --password-file=$JAGD/conf/tmpsyncpass.txt -az $remip::jaguardata/$previp/ $JAGD/pdata/
	if (( htot > 2 )); then
		### get ndata
		echo "Sync data from $remip/$nextip/ to $JAGD/ndata/ ..."
		rsync -q --contimeout=10 --password-file=$JAGD/conf/tmpsyncpass.txt -az $remip::jaguardata/$nextip/ $JAGD/ndata/
	fi
fi

echo "Please start jaguar server on all hosts in the cluster"

