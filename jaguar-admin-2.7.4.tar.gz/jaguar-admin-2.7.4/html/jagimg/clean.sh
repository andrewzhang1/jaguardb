#!/bin/sh


path5840=/usr/local/apache2wg/htdocs/brand5840/img5840
pathcyan=/usr/local/apache2wg/htdocs/brandcyanlotus/img5840

for i in *.gif
do
	i5840=$path5840/$i

	if [[ ! -f $i5840 ]]
	then
		/bin/rm -f $i
		continue
	fi

	if ! diff $i $i5840
	then 
	    echo $i  
	fi 
done

for i in yfile xiaoxi16 viademo viasend viaapply vialogin twop top.gif tijiao smileytitle smallpen slashline shezhitopbar secuopt receivemaillog questmark pensign menuzip
do
	/bin/rm -f ${i}* 
	/bin/rm -f $path5840/${i}*
	/bin/rm -f $pathcyan/${i}*
done
