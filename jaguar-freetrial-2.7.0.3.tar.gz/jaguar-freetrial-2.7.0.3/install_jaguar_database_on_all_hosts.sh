#!/bin/bash

##############################################################################################################
##
##  Server Installation Script  -- Install Jaguar Database on All Hosts in HOSTSFILE
##
##  ./install_jaguar_database_on_all_hosts.sh  -f <HOSTSFILE>  (Install to $HOME directory)
##  ./install_jaguar_database_on_all_hosts.sh  -f <HOSTSFILE>  [-d <INSTALL_DIR>]  (Install to INSTALL_DIR)
##
##############################################################################################################

function usage()
{
    echo "Usage: ./install_jaguar_database_on_all_hosts.sh [OPTION] -f HOSTFILE"
    echo "Install Jaguar database software on all hosts specified by -f HOSTFILE"
    echo "  [-help]           Display help text and exit."
    echo "  [-d DIRECTORY]    Install Jaguar in DIRECTORY. " 
    echo "                    If not provided, Jaguar will be installed in $HOME directory"
    echo "  [-f HOSTFILE]     Install Jaguar database on all the hosts in HOSTFILE."
    echo " "
    echo "In the HOSTFILE, each line must contain a host IP and its host name, separated by space(s)."
    echo " "
    echo "Example of HOSTFILE:"
    echo "192.168.2.110  node0"
    echo "192.168.2.111  node1"
    echo "192.168.2.112  node2"
    echo "192.168.2.113  node3"
    echo "192.168.2.114  node4"
    echo "192.168.2.115  node5"
    echo " "
    echo "All host IPs or names must be unique in the HOSTFILE."
}



pd=`pwd`
dirTar=`dirname $pd`
ver=`basename $pd`
tarfile="${ver}.tar.gz"
tarpathfile="$dirTar/${ver}.tar.gz"
jaguarhome=$HOME
hostfile=""
dirInstall=""
options=""

## Traverse all options given for this shell script
i=0
for arg in "$@"
do
    i=`expr $i + 1`
    case $arg in
        "-f")
            i_next=`expr $i + 1`
            if [ $i_next -le $# ]
            then
                hostfile=${!i_next}
            else
				usage
                exit 1
            fi
            ;;

        "-d")
            i_next=`expr $i + 1`
            if [ $i_next -le $# ]
            then
                jaguarhome=${!i_next}
            else
				usage
                exit 1
            fi
            ;;
        "-help")
            usage
            ;;
        "-h")
            usage
            ;;
        *)
            i_previous=`expr $i - 1`
            if [ ${!i_previous} != "-f" -a ${!i_previous} != "-d" ]
            then
            	usage
                exit 1
            fi
            ;;
    esac
done


JAGUAR_HOME=$jaguarhome
if [[ -e "$JAGUAR_HOME" ]]; then
    echo "OK, install jaguar files to $JAGUAR_HOME ..."
	echo $JAGUAR_HOME > .jaguarhome
else
    echo "JAGUAR_HOME $JAGUAR_HOME does not exist, exit"
    exit 1
fi


if [[ -f "$hostfile" ]]; then
    echo "OK, $hostfile is found"
	awk '{print $1}' $hostfile > cluster.conf
else
    echo "Hostfile $hostfile is not found, exit"
	usage
    exit 1
fi


echo "Set up ssh public keys on all hosts ..."
./setupsshkeys -f $hostfile

randstr=`cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 32|head -1`

echo "Install Jaguar on all other hosts ..."
allhosts=`awk '{print $2}' $hostfile`
awk '{print $2}' $hostfile > .hostfile
for h in $allhosts
do
	ssh $h "mkdir -p ~/jaguardownload"

	echo scp $tarpathfile $h:~/jaguardownload/
	scp $tarpathfile $h:~/jaguardownload/

    echo "ssh $h mkdir -p $JAGUAR_HOME; cd ~/jaguardownload; tar -zxf $tarfile; cd $ver; ./install.sh -d $JAGUAR_HOME -r $randstr"
    ssh $h "mkdir -p $JAGUAR_HOME; cd ~/jaguardownload; tar -zxf $tarfile; cd $ver; ./install.sh -d $JAGUAR_HOME -r $randstr"

	echo scp cluster.conf $h:$JAGUAR_HOME/jaguar/conf/
	scp cluster.conf $h:$JAGUAR_HOME/jaguar/conf/
done


