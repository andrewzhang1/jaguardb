#!/bin/bash

JAGUAR_HOME=$HOME
DIR=$JAGUAR_HOME/jagadmin

/bin/mkdir -p $DIR/log
/bin/mkdir -p $DIR/bin
/bin/mkdir -p $DIR/data
/bin/mkdir -p $DIR/conf

echo "Generate key files for SSL connection of httpd ..."
./makesslkeys.sh

if [[ -f "$JAGUAR_HOME/jagadmin/bin/jagadminstop" ]]; then
	echo "Stopping jagadmin server ..."
    $JAGUAR_HOME/jagadmin/bin/jagadminstop
	echo "Stopped jagadmin server "
fi
/bin/cp -f jagadmin* index.cgi makesslkeys.sh jaguarall* jaguarop $DIR/bin
if [[ -f "$JAGUAR_HOME/jagadmin/bin/jagadminstart" ]]; then
	echo "Starting jagadmin server ..."
    $JAGUAR_HOME/jagadmin/bin/jagadminstart
	echo "Started jagadmin server"
fi

if type httpd >/dev/null 2>&1
then
    echo "Your httpd server exists already"
    echo
    echo -n "httpd server root directory: "
    rootdir=`httpd -V |grep HTTPD_ROOT| awk '{print $2}'|awk -F'=' '{gsub(/"/, "", $2);print $2}'`
    echo "$rootdir"
    echo
    echo -n "httpd server config file: "
    cfgfile=`httpd -V |grep SERVER_CONFIG_FILE| awk '{print $2}'|awk -F'=' '{gsub(/"/, "", $2);print $2}'`
    echo "$rootdir/$cfgfile"
    echo
    echo "Files in $rootdir/conf.d directory:"
    /bin/ls -lrt $rootdir/conf.d/
    echo
	echo "Installed jagdmin successfully in $DIR/bin"
	echo "Please read the readme file for further instructions"
    echo
else
    echo "Apache httpd server does not exist on the host."
    echo "You need to install it following the instructions in the readme file."
    echo
fi

echo "Please copy the index.cgi file to your httpd /cgi-bin/ directory"
echo

