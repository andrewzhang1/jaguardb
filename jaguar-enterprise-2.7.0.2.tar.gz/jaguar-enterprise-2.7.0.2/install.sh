#!/bin/bash

##############################################################################################################
##
##  Server Installation Script
##
##  ./install.sh                    (Install to $HOME directory. You should install it on each host in your cluster)
##  ./install.sh -d <INSTALL_DIR>   (Install to INSTALL_DIR. You should install it on each host in your cluster)
##
##############################################################################################################

JAGUAR_HOME=$HOME

if [[ "x$1" = "x-d" ]]; then
    JAGUAR_HOME=$2
    if [[ "x$JAGUAR_HOME" = "x" ]]; then
        echo "Usage:  ./install.sh -d <JAGUAR_HOME>"
        echo "Usage:  ./install.sh"
        exit 1
    fi

    if [[ -e "$JAGUAR_HOME" ]]; then
        echo "OK, install jaguar files to $JAGUAR_HOME ..."
    else
        echo "$JAGUAR_HOME does not exist, exit"
        exit 1
    fi
fi


cwd=`pwd`
cd $cwd/server
if [[ "x$JAGUAR_HOME" != "x$HOME" ]]; then
	./install.sh -d $JAGUAR_HOME
else
	./install.sh
fi

cd $cwd/client
if [[ "x$JAGUAR_HOME" != "x$HOME" ]]; then
	./install.sh -d $JAGUAR_HOME
else
	./install.sh
fi

echo "Jaguar installation complete"

